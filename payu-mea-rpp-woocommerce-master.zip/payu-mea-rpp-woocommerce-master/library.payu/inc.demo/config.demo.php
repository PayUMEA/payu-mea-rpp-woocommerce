<?php
	/**
	 * class-wc-gateway-payu.php
	 *
	 * Copyright (coffee) 2012-2013 PayU MEA (Pty) Ltd
	 * 
	 * LICENSE:
	 * 
	 * This payment module is free software; you can redistribute it and/or modify
	 * it under the terms of the GNU Lesser General Public License as published
	 * by the Free Software Foundation; either version 3 of the License, or (at
	 * your option) any later version.
	 * 
	 * This payment module is distributed in the hope that it will be useful, but
	 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
	 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
	 * License for more details.
	 * 
	 * @author     Warren Roman/Ramiz Mohamed
	 * @copyright  2011-2013 PayU Payment Solutions (Pty) Ltd
	 */	

//-----------------------------------
//---  RPP
//-----------------------------------
$rpp['username'] = 'Staging Integration Store 1';
$rpp['password'] = '78cXrW1W';
$rpp['Safekey'] = '{45D5C765-16D2-45A4-8C41-8D6F84042F8C}';

//-----------------------------------
//---  SS Pro
//-----------------------------------
$ssPro['Safekey'] = '{E7831EC1-AA49-4ADB-893E-408C3683B633}';

//-----------------------------------
//---  SS Ent
//-----------------------------------
$ssEnt['Safekey'] = '{45D5C765-16D2-45A4-8C41-8D6F84042F8C}';